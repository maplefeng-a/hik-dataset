package main

import (
	"github.com/maplefeng-a/hikctl/cmd"
)

func main() {
	cmd.Execute()
}
